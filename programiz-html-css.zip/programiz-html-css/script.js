document.addEventListener("DOMContentLoaded", function () {
    // Example: Can add interactivity here if needed
    console.log("Bone Health website loaded successfully!");
});
